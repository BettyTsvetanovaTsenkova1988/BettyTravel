﻿using System.Collections.Generic;
using System.Web.Mvc;
using BettyTravel.Services;
using BettyTravelApp.Models.ViewModels.Vacation;

namespace BettyTravelApp.Controllers
{

    public class HomeController : Controller
    {
        private HomeService service;

        public HomeController()
        {
            this.service = new HomeService();
        }


        [AllowAnonymous]
        public ActionResult Index()
        {
            IEnumerable<AllVacationsViewModel> allVacations = this.service.GetAllVacations();
            return View(allVacations);
        }


        public ActionResult About()
        {
            ViewBag.Message = "Кои сме ние?";

            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
    }
}