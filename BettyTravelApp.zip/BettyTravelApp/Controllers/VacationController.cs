﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BettyTravel.Services;
using BettyTravelApp.Models.ViewModels.Vacation;

namespace BettyTravelApp.Controllers
{
    [RoutePrefix("vacations")]
    [AllowAnonymous]
    public class VacationController : Controller
    {
        private VacationService service;

        public VacationController()
        {
            this.service = new VacationService();
        }


        [HttpGet, Route("details/{id}")]
        public ActionResult Details(int id)
        {
            VacationDetailsViewModel vm = this.service.GetDetails(id);
            if (vm == null)
            {
                return this.HttpNotFound();
            }

            return this.View(vm);
        }

      
    }
}