﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BettyTravel.Services;
using BettyTravelApp.Models.EntityModels;

namespace BettyTravelApp.Controllers
{
    [Authorize(Roles = "customer")]
    [RoutePrefix("Customer")]
    public class CustomerController : Controller
    {
        private CustomerService service;

        public CustomerController()
        {
            this.service = new CustomerService();
        }

        [HttpPost]
        [Route("buy/{vacationId}")]
        public ActionResult BuyVacation(int vacationId)
        {
            string customerName = this.User.Identity.Name;
            Customer customer = this.service.GetCurrentCustomer(customerName);
            this.service.BuyVacation(vacationId, customer);

            return this.View();
        }
    }
}